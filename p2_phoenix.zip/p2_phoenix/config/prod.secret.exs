use Mix.Config

# In this file, we keep production configuration that
# you'll likely want to automate and keep away from
# your version control system.
#
# You should document the content of this
# file or create a script for recreating it, since it's
# kept out of version control and might be hard to recover
# or recreate for your teammates (or yourself later on).
config :p2_phoenix, P2PhoenixWeb.Endpoint,
  secret_key_base: "ICJuubihhjlUzkpTk8V50Rwu/KAvfEZV45duxpxCE8AXUxwTKfJsmRYkCD3gkQqa"

# Configure your database
config :p2_phoenix, P2Phoenix.Repo,
  adapter: Ecto.Adapters.Postgres,
  username: "postgres",
  password: "postgres",
  database: "p2_phoenix_prod",
  pool_size: 15
